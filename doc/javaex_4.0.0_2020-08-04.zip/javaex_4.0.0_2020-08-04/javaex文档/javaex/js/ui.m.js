document.write('<link href="../javaex/m/css/icomoon.css" rel="stylesheet" />');
document.write('<link href="../javaex/m/css/common.css" rel="stylesheet" />');
document.write('<link href="../javaex/m/css/animate.css" rel="stylesheet" />');
document.write('<link href="../javaex/m/css/skin/default.css" rel="stylesheet" />');
document.write('<script src="../javaex/m/lib/jquery-3.3.1.min.js"></script>');
document.write('<script src="../javaex/m/js/flexible.js"></script>');
document.write('<script src="../javaex/m/js/common.js"></script>');
document.write('<script src="../javaex/m/js/javaex.min.js"></script>');
document.write('<script src="../javaex/m/js/javaex-formVerify.js"></script>');
